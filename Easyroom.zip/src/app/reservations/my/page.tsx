// src/app/reservations/my/page.tsx

'use client';

import { ReservationListView } from '@/features/reservation/components/ReservationListView';
import AppLayout from '@/components/layout/AppLayout';
import { useMyReservations } from '@/hooks/useReservations';
import { useAuth } from '@/hooks/useAuth';
import { Container, Stack, Paper, Group, ThemeIcon, Title, Text, Skeleton } from '@mantine/core';
import { Calendar, User } from 'lucide-react';

export default function MyReservationsPage() {
  const { userProfile } = useAuth();
  
  const { data: reservations, isLoading, isError } = useMyReservations(userProfile?.dbId);

  return (
    <AppLayout headerTitle="내 예약 관리">
      <Container my="xl" size="lg">
        <Stack gap="xl">
          {/* 헤더 섹션 */}
          <Paper
            p="xl"
            radius="xl"
            style={{
              background: 'linear-gradient(135deg, #059669 0%, #047857 100%)',
              color: 'white'
            }}
          >
            <Group align="center" gap="md">
              <ThemeIcon size="lg" radius="xl" color="white" variant="light" style={{ background: 'rgba(255,255,255,0.2)' }}>
                <Calendar size={24} />
              </ThemeIcon>
              <Stack gap={4}>
                <Title order={2} c="white">
                  내 예약 관리
                </Title>
                <Text c="rgba(255,255,255,0.8)" size="sm">
                  {userProfile?.name || '사용자'}님의 회의실 예약 현황을 확인하고 관리하세요
                </Text>
              </Stack>
            </Group>
          </Paper>

          {/* 콘텐츠 섹션 */}
          {isLoading ? (
            <Stack gap="md">
              <Skeleton height={60} radius="xl" />
              <Skeleton height={120} radius="xl" />
              <Skeleton height={120} radius="xl" />
              <Skeleton height={120} radius="xl" />
            </Stack>
          ) : (
            <ReservationListView
              reservations={reservations}
              isError={isError}
            />
          )}
        </Stack>
      </Container>
    </AppLayout>
  );
}